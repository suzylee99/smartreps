import React, { useState, useEffect } from 'react';
import AnimatedBackground from './components/AnimatedBackground';
import RoleSelection from './components/RoleSelection';
import EmployeeDashboard from './components/EmployeeDashboard';
import CompanyDashboard from './components/CompanyDashboard';
import LoginModal from './components/LoginModal';
import Modal from './components/Modal';
import { Button } from './components/ui/button';
import { getUser, isAuthenticated } from './utils/auth';

type View = 'landing' | 'dashboard';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    // Check if user is already authenticated
    if (isAuthenticated()) {
      const userData = getUser();
      setUser(userData);
      setCurrentView('dashboard');
    }
  }, []);

  const handleSignUp = () => {
    setShowRoleModal(true);
  };

  const handleLogin = () => {
    setShowLoginModal(true);
  };

  const handleRoleSelected = (userData: any) => {
    setUser(userData);
    setCurrentView('dashboard');
    setShowRoleModal(false);
  };

  const handleLoginSuccess = (userData: any) => {
    setUser(userData);
    setCurrentView('dashboard');
    setShowLoginModal(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    setCurrentView('landing');
    setUser(null);
  };

  const renderDashboard = () => {
    if (!user) return null;
    
    switch (user.role) {
      case 'employee':
        return <EmployeeDashboard user={user} />;
      case 'company':
        return <CompanyDashboard user={user} />;
      case 'mentor':
        return <EmployeeDashboard user={user} /> // Reuse for now
      case 'consultant':
        return <EmployeeDashboard user={user} /> // Reuse for now
      default:
        return <EmployeeDashboard user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      <AnimatedBackground />
      
      {/* Navigation */}
      <nav className="relative z-10 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
            <span className="text-black font-bold text-xl">S</span>
          </div>
          <span className="text-xl font-bold text-emerald-400">Smartreps</span>
        </div>
        <div className="flex space-x-4">
          {currentView === 'landing' && (
            <>
              <Button 
                variant="ghost" 
                className="text-emerald-400 hover:text-emerald-300"
                onClick={handleLogin}
              >
                Login
              </Button>
              <Button 
                onClick={handleSignUp}
                className="bg-emerald-500 hover:bg-emerald-600 text-black font-semibold"
              >
                Sign Up
              </Button>
            </>
          )}
          {currentView === 'dashboard' && user && (
            <div className="flex items-center space-x-4">
              <span className="text-emerald-400">Welcome, {user.name}</span>
              <Button 
                variant="ghost" 
                className="text-emerald-400 hover:text-emerald-300"
                onClick={handleLogout}
              >
                Logout
              </Button>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10">
        {currentView === 'landing' && (
          <div className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] px-6">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 text-center bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              From Skill to Salary
            </h1>
            <p className="text-2xl md:text-3xl text-emerald-300 mb-12 text-center">
              Guaranteed.
            </p>
            <div className="flex space-x-4">
              <Button 
                onClick={handleLogin}
                size="lg"
                variant="outline"
                className="border-emerald-500 text-emerald-400 font-bold text-xl px-12 py-6 rounded-full hover:bg-emerald-500/10 transition-all duration-300"
              >
                Login
              </Button>
              <Button 
                onClick={handleSignUp}
                size="lg"
                className="bg-emerald-500 hover:bg-emerald-600 text-black font-bold text-xl px-12 py-6 rounded-full shadow-lg shadow-emerald-500/50 hover:shadow-emerald-500/70 transition-all duration-300"
              >
                Sign Up
              </Button>
            </div>
          </div>
        )}

        {currentView === 'dashboard' && user && renderDashboard()}
      </div>

      {/* Role Selection Modal */}
      <Modal isOpen={showRoleModal} onClose={() => setShowRoleModal(false)}>
        <RoleSelection onRoleSelected={handleRoleSelected} />
      </Modal>

      {/* Login Modal */}
      <Modal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)}>
        <LoginModal onLoginSuccess={handleLoginSuccess} />
      </Modal>
    </div>
  );
}